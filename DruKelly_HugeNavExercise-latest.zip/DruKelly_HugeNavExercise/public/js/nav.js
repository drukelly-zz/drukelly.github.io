(function() {

  this.Navigation = function() {
    const _this = this;

    this.openedBodyClass = 'nav-opened';

    const defaults = {
      navElement: 'navigation',
      chevronImage: 'images/chevronImage.svg',
      JSONDataURL: '/api/nav.json',
      afterRender: function() {}
    };

    if (arguments[0] && typeof arguments[0] === 'object') {
      this.opts = extendDefaults(defaults, arguments[0]);
    } else {
      this.opts = defaults;
    }

    const bodyElement = document.querySelector('body');
    bodyElement.addEventListener('click', bodyClick.bind(this));

    const hamburgerElement = document.getElementById('toggle-open-close');
    if (hamburgerElement) {
      hamburgerElement.addEventListener('click', toggleMenu.bind(this));
    }

    loadMenuFromJSON.call(this, this.opts.JSONDataURL, function(menuObj) {
      buildMenu.call(_this, _this.opts.navElement, menuObj);
      _this.opts.afterRender();
    });

    function loadMenuFromJSON(JSONURL, callback) {
      const _this = this,
          req = new XMLHttpRequest();

      req.onload = function (e) {
        callback.call(_this, e.target.response);
      };
      req.open('GET', JSONURL, true);
      req.responseType = 'json';
      req.send();
    }

    function buildMenu(nav, menuObj) {
      const navElement = document.getElementById(nav),
            navMainUL = document.createElement('ul');
            navMainUL.classList.add('navbar');

      for (let i = 0; i < menuObj.items.length; i++) {
        const navLI = document.createElement('li'),
              itemObj = menuObj.items[i];

        if (itemObj.items.length > 0) {
          const subNavUL = document.createElement('ul');
          for (let j = 0; j < itemObj.items.length; j++) {
            const subNavLI = document.createElement('li');
            subItemObj = itemObj.items[j];

            const subNavLink = document.createElement('a');
            subNavLink.setAttribute('href', subItemObj.url);
            subNavLink.innerHTML = subItemObj.label;
            subNavLink.addEventListener('click', closeMenu.bind(this));
            subNavLI.appendChild(subNavLink);
            subNavUL.appendChild(subNavLI);
          }

          const spanLabel = document.createElement('a');
          spanLabel.innerHTML = itemObj.label;
          spanLabel.setAttribute('href', itemObj.url);
          spanLabel.addEventListener('click', openMenu.bind(this));

          if (this.opts.chevronImage) {
            const chevronImageArrow = document.createElement('img');
            chevronImageArrow.setAttribute('src', this.opts.chevronImage);
            spanLabel.appendChild(chevronImageArrow);
          }

          navLI.appendChild(spanLabel);
          navLI.appendChild(subNavUL);
        } else {
          const menuLink = document.createElement('a');
          menuLink.setAttribute('href', itemObj.url);
          menuLink.innerHTML = itemObj.label;
          navLI.addEventListener('click', closeMenu.bind(this));
          navLI.appendChild(menuLink);
        }
        navMainUL.appendChild(navLI);
      }
      navElement.appendChild(navMainUL);
    }

    function bodyClick(e) {
      const navElement = closest(e.target, 'nav');
      if (!navElement) {
        closeMenu.apply(this);
      }
    }

  };

  function toggleMenu() {
    const bodyElement = document.querySelector('body');
    if (bodyElement.classList.contains(this.openedBodyClass)) {
      bodyElement.classList.remove(this.openedBodyClass);
    } else {
      bodyElement.classList.add(this.openedBodyClass);
    }
  }

  function openMenu(e) {
    const openedMenu = document.querySelector('.opened'),
          bodyElement = document.querySelector('body');

    if (openedMenu) {
      openedMenu.classList.remove('opened');
    }

    e.target.parentNode.classList.add('opened');
    bodyElement.classList.add(this.openedBodyClass);
  }

  function closeMenu() {
    const openedMenu = document.querySelector('.opened'),
          bodyElement = document.querySelector('body');
    if (openedMenu) {
      openedMenu.classList.remove('opened');
    }
    bodyElement.classList.remove(this.openedBodyClass);
  }

  function extendDefaults(source, properties) {
    const property = [];
    for (property in properties) {
      if (properties.hasOwnProperty(property)) {
        source[property] = properties[property];
      }
    }
    return source;
  }

  function closest(element, tagname) {
    var tagname = tagname.toLowerCase();
    do {
      if (element.nodeName.toLowerCase() === tagname) {
        return element;
      }
    } while (element = element.parentNode);
    return null;
  }

}());